package br.ufc.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name="ALBUM")
public class Album {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="AL_ID",nullable=false)
	private Long al_id; 

	@Column(name="NOME")
	private String nome;

	// MANY-TO-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="USU_ID",referencedColumnName="USU_ID")
	private Usuario usuario ;

	//	ONE-2-MANY
	@OneToMany(mappedBy="album",targetEntity=Foto.class,fetch=FetchType.EAGER)
	private Collection<Foto> fotos;

	public Long getAl_id() {
		return al_id;
	}

	public void setAl_id(Long al_id) {
		this.al_id = al_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Collection<Foto> getFotos() {
		return fotos;
	}

	public void setFotos(Collection<Foto> fotos) {
		this.fotos = fotos;
	}

}
