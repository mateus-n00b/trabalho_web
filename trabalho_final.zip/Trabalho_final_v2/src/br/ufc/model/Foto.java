package br.ufc.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name="FOTO")
public class Foto {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FOT_ID")
	private Long fot_id;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="USU_ID",
	referencedColumnName="USU_ID")		
	private Usuario usuario;	
	// MANY-2-ONE

	// ONE-TO-MANY
	@OneToMany(mappedBy="foto",targetEntity=Comentario.class,fetch=FetchType.EAGER)
	private Collection<Comentario> comentarios;
	// ONE-TO-MANY
	
	// MANY-2-ONE
		@ManyToOne(optional=false)
		@JoinColumn(name="AL_ID",
		referencedColumnName="AL_ID")	
		private Album album;

	@Column(name="IMAGEM")
	private String imagem;
	
	@Column(name="CURTIDAS")
	private Long curtidas; 
	
	public Long getFot_id() {
		return fot_id;
	}

	public void setFot_id(Long fot_id) {
		this.fot_id = fot_id;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Collection<Comentario> getComentarios() {
		return comentarios;
	}

	public void setComentarios(Collection<Comentario> comentarios) {
		this.comentarios = comentarios;
	}

	public Album getAlbum() {
		return album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}

	public Long getCurtidas() {
		return curtidas;
	}

	public void setCurtidas(Long curtidas) {
		this.curtidas = curtidas;
	}
	
	
}
