package br.ufc.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;


@Entity(name="COMUNIDADE")
public class Comunidade {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="COM_ID",nullable=false)
	private Long com_id;

	@Column(name="NOME")
	private String nome;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="ORK_ID",referencedColumnName="ORK_ID")	
	private Orkut orkut;
	// MANY-2-ONE

	@Column(name="IDENTIFIER",nullable=true)
	private Long aux; 
	
	// MANY-TO-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="CAT_ID",referencedColumnName="CAT_ID")	
	private Categoria categoria;
	// MANY-TO-ONE	

	// ONE-2-MANY
	@OneToMany(mappedBy="comunidade",targetEntity=Forum.class,fetch=FetchType.EAGER)
	private List<Forum> forum = new ArrayList<Forum>();
	// ONE-2-MANY


	@ManyToMany
	@JoinTable(name="USUARIO_COMUNIDADE",
	joinColumns=@JoinColumn(name="COM_ID",referencedColumnName="COM_ID"),
	inverseJoinColumns=@JoinColumn(name="USU_ID", referencedColumnName="USU_ID"))
	private List<Usuario> usuarios;
	

	public Long getCom_id() {
		return com_id;
	}

	public void setCom_id(Long com_id) {
		this.com_id = com_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

/*	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
*/
	public Orkut getOrkut() {
		return orkut;
	}

	public void setOrkut(Orkut orkut) {
		this.orkut = orkut;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public List<Forum> getForum() {
		return forum;
	}

	public void setForum(List<Forum> forum) {
		this.forum = forum;
	}

	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public Long getAux() {
		return aux;
	}

	public void setAux(Long aux) {
		this.aux = aux;
	}
	
}
