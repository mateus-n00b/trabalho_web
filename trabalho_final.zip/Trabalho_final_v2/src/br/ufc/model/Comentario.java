package br.ufc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="COMENTARIO")
public class Comentario {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="COM_ID")
	private Long com_id;

	@Column(name="TEXTO")
	private String texto;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="FOT_ID",
	referencedColumnName="FOT_ID")		
	private Foto foto;	
	// MANY-2-ONE

	//	Modifiquei esta classe
	@Column(name="USU_ID")
	private Long usu_id;
	
	@Column(name="LOGIN")
	private String login;

	public Long getCom_id() {
		return com_id;
	}

	public void setCom_id(Long com_id) {
		this.com_id = com_id;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Foto getFoto() {
		return foto;
	}

	public void setFoto(Foto foto) {
		this.foto = foto;
	}

	public Long getUsu_id() {
		return usu_id;
	}

	public void setUsu_id(Long usu_id) {
		this.usu_id = usu_id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

}
