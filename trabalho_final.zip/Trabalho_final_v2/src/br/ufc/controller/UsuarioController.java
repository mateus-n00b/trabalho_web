package br.ufc.controller;

import java.util.List;
import org.apache.commons.codec.digest.DigestUtils;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Categoria;
import br.ufc.model.Mensagem;
import br.ufc.model.Usuario;
import br.ufc.util.AulaFileUtil;

@Controller
@Transactional
public class UsuarioController {

	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;

	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;

	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;

	@Autowired
	private ServletContext context;

	// Criar um novo usuario
	@RequestMapping("/inserirUsuarioFormulario")
	public String inserirUsuarioFormulario(){
		return "usuarios/inserir_usuario";
	}

	@RequestMapping("/inserirUsuario")
	public String inserirUsuario(Usuario usuario, 
			@RequestParam(value="image",required=false) MultipartFile image){
		//MessageDigest msg = MessageDigest.getInstance("MD5");

		if ( image != null && !image.isEmpty() ){
			String path = context.getRealPath("/");
			path+="resources/images/"+usuario.getLogin()+".png";
			AulaFileUtil.saveFile(path, image);
		}		
		usuario.setSenha(DigestUtils.md5Hex(usuario.getSenha()));	
//		System.out.println(">> "+s);
		usuarioDAO.inserir(usuario);
		return "redirect:loginForm";
	}

	//Listar
	@RequestMapping("/listarUsuarios")
	public String listarUsuarios(Model model){		 
		List<Usuario> users = usuarioDAO.listar();
		model.addAttribute("usuarios", users);	

		return "usuarios/listar";
	}
	//Apagar
	@RequestMapping("/apagarUsuario")
	public String apagarUsuario(Long id){
		usuarioDAO.apagar(id);
		return "redirect:logout";
	}	 

	// Alterar informacoes
	@RequestMapping("/alterarForm")
	public String alterarForm(Long id,Model model){
		Usuario u = usuarioDAO.recuperar(id);
		model.addAttribute("usuario",u);
		return "usuarios/alterar";
	}

	@RequestMapping("/alterarUsuario")
	public String alterarUsuario(Usuario u){
		usuarioDAO.alterar(u);
		return "redirect:listarUsuarios";
	}

	// Voltar para pagina inicial
	@RequestMapping("toHome")
	public String toHome(Model model){
		List<Mensagem> m = forumDAO.listarMensagens();
		model.addAttribute("msg",m);		
		return "usuarios/home";
	}

	//	Realizar cadastro na comunidade
	public String cadastroComunidade(Long id){

		return "";
	}

	// Configuracoes
	@RequestMapping("/configuracoes")
	public String configuracoes(){
		return "usuarios/configuracoes";
	}

	// Listar Categorias
	@RequestMapping("/listarCategoria")
	public String ListarCategoria(Model model){		
		List<Categoria> c = categoriaDAO.listarCategoria();
		model.addAttribute("categorias",c);
		return "categorias/listarCategoria";
	}

	// Curtidas
	@RequestMapping("/curtir")
	public String curtir(Long id){
		Mensagem m  = mensagemDAO.recuperar(id);
		m.setCurtidas(m.getCurtidas()+1);
		mensagemDAO.curtir(m);
		return "redirect:toHome";
	}

	//	Visitar o perfil do usuario X
	@RequestMapping("/visitarPerfil")
	public String visitarPerfil(Model model , Long id){		
		Usuario u = usuarioDAO.recuperar(id);
		model.addAttribute("perfil",u);
		return "usuarios/perfil";
	}

	//	Ver fotos do usuario X
	//	FOTODAO -> foto.merge(NomeDaFoto)
	// Recupero todos os nomes caminhos e no JSP itero por eles
	public String verFotos(){
		return "";
	}

}
