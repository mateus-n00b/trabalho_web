package br.ufc.controller;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.form.AmizadeCheckBoxForm;
import br.ufc.model.Amizade;
import br.ufc.model.Categoria;
import br.ufc.model.Comunidade;
import br.ufc.model.Forum;
import br.ufc.model.Mensagem;
import br.ufc.model.Usuario;
import br.ufc.util.AulaFileUtil;

@Controller
@Transactional
public class UsuarioController {

	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;
	
	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;
	
	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;
	
	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;
	
	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;
	
	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;
	
	@Autowired
	private ServletContext context;
	
	// Criar um novo usuario
	@RequestMapping("/inserirUsuarioFormulario")
	public String inserirUsuarioFormulario(){
		return "usuarios/inserir_usuario";
	}

	@RequestMapping("/inserirUsuario")
	public String inserirUsuario(Usuario usuario, 
			@RequestParam(value="image",required=false) MultipartFile image){
		//MessageDigest msg = MessageDigest.getInstance("MD5");
		
		if ( image != null && !image.isEmpty() ){
			String path = context.getRealPath("/");
			path+="resources/images/"+usuario.getLogin()+".png";
			AulaFileUtil.saveFile(path, image);
		}
		//usuario.setSenha();
		usuarioDAO.inserir(usuario);
		return "redirect:loginForm";
	}

	//Listar
	@RequestMapping("/listarUsuarios")
	public String listarUsuarios(Model model){		 
		List<Usuario> users = usuarioDAO.listar();
		model.addAttribute("usuarios", users);	

		return "usuarios/listar";
	}
	//Apagar
	@RequestMapping("/apagarUsuario")
	public String apagarUsuario(Long id){
		usuarioDAO.apagar(id);
		return "redirect:logout";
	}	 

	// Alterar informacoes
	@RequestMapping("/alterarForm")
	public String alterarForm(Long id,Model model){
		Usuario u = usuarioDAO.recuperar(id);
		model.addAttribute("usuario",u);
		return "usuarios/alterar";
	}

	@RequestMapping("/alterarUsuario")
	public String alterarUsuario(Usuario u){
		usuarioDAO.alterar(u);
		return "redirect:listarUsuarios";
	}
	
	// Voltar para pagina inicial
	@RequestMapping("toHome")
	public String toHome(Model model){
		List<Mensagem> m = forumDAO.listarMensagens();
		model.addAttribute("msg",m);		
		return "usuarios/home";
	}

	//Inserir Amizades
	@RequestMapping("/inserirAmizadeForm")
	public String inserirAmizadeForm(HttpSession session, Model model){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		List<Usuario> broderagi = usuarioDAO.listar(); 
		broderagi.remove(u);
		
		AmizadeCheckBoxForm acf = new AmizadeCheckBoxForm();
		List<Amizade> minhasAmizades = this.amizadeDAO.listarAmizadesDeId(u.getUsu_id());		
		
		if (minhasAmizades != null && minhasAmizades.size() > 0){
			//Long[] vetorId = new Long[minhasAmizades.size()];
			//int i = 0;
			
			for(Amizade a: minhasAmizades){
				Long amigoId = a.getUsuarioAlvo().getUsu_id();
				Usuario amigoTemp = new Usuario();
				amigoTemp.setUsu_id(amigoId);
				broderagi.remove(amigoTemp);
				
				//vetorId[i] = amigoId;
				//i++;
			}
			//acf.setAmigos(vetorId);
		}
		
		model.addAttribute("amizades",acf);		
		model.addAttribute("usuario",u);
		model.addAttribute("amizade",broderagi);
		
		return "usuarios/inserir_amizade_form";
	}	
	
	// Criar broderagi
	@RequestMapping("/inserirAmizade")
	public String inserirAmizade(HttpSession session, AmizadeCheckBoxForm amizades){
		
		Usuario amigoFonte = (Usuario) session.getAttribute("usuario_logado");
		
		for (Long id : amizades.getAmigos()){
			Usuario amigoAlvo = usuarioDAO.recuperar(id);
			Amizade amizade = new Amizade();
			
			// Se sou amigo de X...
			amizade.setUsuarioFonte(amigoFonte);
			amizade.setUsuarioAlvo(amigoAlvo);						
			amizadeDAO.inserir(amizade);
			// Entao X e meu amigo			
			Amizade a = new Amizade();
			a.setUsuarioFonte(amigoAlvo);
			a.setUsuarioAlvo(amigoFonte);									
			amizadeDAO.inserir(a);
		}
		return "redirect:listarUsuarios";
	}
	
	// Listar Amigos
	@RequestMapping("/listarAmizade")
	public String listarAmizade(HttpSession session, Model model){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		
		List<Amizade> amigos = this.amizadeDAO.listarAmizadesDeId(u.getUsu_id());
		// Array para armazenar todos os amigos do usuario atual
		List<Usuario> usuarios = new ArrayList<Usuario>(); 
		
		for(Amizade a: amigos){
			Long amigoId = a.getUsuarioAlvo().getUsu_id();			
			Usuario usuario = usuarioDAO.recuperar(amigoId);
			usuarios.add(usuario);			
		}
		
//		model.addAttribute("amizades",amigos);
		model.addAttribute("amizades",usuarios);
		return "usuarios/listarAmizade";
	}
	
	// Criar Comunidade
//	@RequestMapping("/criarComunidadeForm")
//	public String criarComunidadeForm(HttpSession session,Long id){
//		Categoria cat = categoriaDAO.recuperar(id);
//		session.setAttribute("cat", cat);		
//		return "comunidades/criarComunidadeForm";
//	}
	@RequestMapping("/criarComunidadeForm")
	public String criarComunidadeForm(Model model){
		List<Categoria> cat = categoriaDAO.listarCategoria();
		model.addAttribute("categorias",cat);
		return "comunidades/criarComunidadeForm";
	}
	
	@RequestMapping("/criarComunidade")
	public String criarComunidade(Comunidade comunidade, 
			@RequestParam(value="image_cat",required=false) 
			MultipartFile image, HttpSession session){
			
			// Popular tabela USUARIO_COMUNIDADE
			List<Usuario> users = new ArrayList<Usuario>();
			Usuario u = (Usuario) session.getAttribute("usuario_logado");
			users.add(u);
			
//			List<Comunidade> coms = new ArrayList<Comunidade>();
//			coms.add(comunidade);
			
			if (image != null && ! image.isEmpty()){
				String path = context.getRealPath("/");
				path+="resources/images/"+comunidade.getNome()+"_com.png";
				AulaFileUtil.saveFile(path, image);
			}
			
			//Gambis is on!!
			Categoria cat = categoriaDAO.recuperar(comunidade.getAux());
			comunidade.setCategoria(cat);
			comunidade.setUsuarios(users);
			comunidadeDAO.criarComunidade(comunidade);
			return "redirect:listarComunidades";
	}
	
	//Listar Comunidades
	@RequestMapping("/listarComunidades")
	public String listarComunidades(Model model){		
		List<Comunidade> comunidades = comunidadeDAO.listarComunidades();
		model.addAttribute("comunidades", comunidades);	
		
		return "comunidades/listarComunidades";
	}
	
//	Realizar cadastro na comunidade
	public String cadastroComunidade(Long id){
		
		return "";
	}
	
	// Listar foruns	
	@RequestMapping("/listarForuns")
	public String listarForuns(Model model, Long id){
		List<Forum> foruns = comunidadeDAO.listarForuns(id);
		model.addAttribute("foruns",foruns);
		return "foruns/listarForuns";
	}
	
	// Configuracoes
	@RequestMapping("/configuracoes")
	public String configuracoes(){
		return "usuarios/configuracoes";
	}
	
	// Criar Forum
	@RequestMapping("/criarForumForm")
	public String criarForumForm(Long id, HttpSession session ){			
		Comunidade c = comunidadeDAO.recuperar(id);
		session.setAttribute("com",c);
		return "foruns/criarForumForm"; 
	}
		
	@RequestMapping("/criarForum")
	public String criarForum(Forum forum, HttpSession session){
		Comunidade c = (Comunidade) session.getAttribute("com");		
		forum.setComunidade(c);
		comunidadeDAO.criarForum(forum);
		return "redirect:listarForuns";
	}
	
	// Listar Categorias
	@RequestMapping("/listarCategoria")
	public String ListarCategoria(Model model){		
		List<Categoria> c = categoriaDAO.listarCategoria();
		model.addAttribute("categorias",c);
		return "categorias/listarCategoria";
	}
	
	// Inserir uma mensagem em um forum
	@RequestMapping("/listarMensagens")
	public String listarMensagens(Model model,Long id){
		List<Mensagem> m = forumDAO.listarMensagensdeId(id);
		model.addAttribute("mensagens",m);
		return "mensagens/listarMensagens";
	}
	
	@RequestMapping("/inserirMensagemForm")
	public String inserirMensagemForm(Long id, HttpSession session){
		Forum f = forumDAO.recuperar(id);
		session.setAttribute("forum",f);
		return "mensagens/inserirMensagemForm";
	}
	
	@RequestMapping("/inserirMensagem")
	public String inserirMensagem(Mensagem mensagem, HttpSession session){		
		Forum f = (Forum) session.getAttribute("forum");
		mensagem.setForum(f);
		forumDAO.inserirMensagem(mensagem);
		return "redirect:listarForuns";
	}
	
	// Curtidas
	@RequestMapping("/curtir")
	public String curtir(Long id){
		Mensagem m  = mensagemDAO.recuperar(id);
		m.setCurtidas(m.getCurtidas()+1);
		mensagemDAO.curtir(m);
		return "redirect:toHome";
	}
	
//	Visitar o perfil do usuario X
	@RequestMapping("/visitarPerfil")
	public String visitarPerfil(Model model , Long id){		
		Usuario u = usuarioDAO.recuperar(id);
		model.addAttribute("perfil",u);
		return "usuarios/perfil";
	}
	
//	Ver fotos do usuario X
//	FOTODAO -> foto.merge(NomeDaFoto)
// Recupero todos os nomes caminhos e no JSP itero por eles
	public String verFotos(){
		
		return "";
	}
	
}
