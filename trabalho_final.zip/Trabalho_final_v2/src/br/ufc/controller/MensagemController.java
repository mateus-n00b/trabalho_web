package br.ufc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Forum;
import br.ufc.model.Mensagem;

@Controller
@Transactional
public class MensagemController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;

	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;

	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;

	@Autowired
	private ServletContext context;
	// Inserir uma mensagem em um forum
	@RequestMapping("/listarMensagens")
	public String listarMensagens(Model model,Long id){
		List<Mensagem> m = forumDAO.listarMensagensdeId(id);
		model.addAttribute("mensagens",m);
		return "mensagens/listarMensagens";
	}

	@RequestMapping("/inserirMensagemForm")
	public String inserirMensagemForm(Long id, HttpSession session){
		Forum f = forumDAO.recuperar(id);
		session.setAttribute("forum",f);
		return "mensagens/inserirMensagemForm";
	}

	@RequestMapping("/inserirMensagem")
	public String inserirMensagem(Mensagem mensagem, HttpSession session){		
		Forum f = (Forum) session.getAttribute("forum");
		mensagem.setForum(f);
		forumDAO.inserirMensagem(mensagem);
		return "redirect:listarForuns";
	}


}
