package br.ufc.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.*;
import br.ufc.model.*;

@Controller
@Transactional
public class LoginController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO userDAO;


	@RequestMapping("/loginForm")
	public String loginForm(){
		return "usuarios/login_form";
	}

	@RequestMapping("/login")
	public String login(Usuario u,HttpSession session){
		Usuario user = userDAO.recuperar(u.getLogin());
		if(user != null){
			if(user.getSenha().equals(u.getSenha())){
				session.setAttribute("usuario_logado", user);
				return "redirect:toHome";
			}
		}
		return "redirect:loginForm";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:loginForm";
	}

}




