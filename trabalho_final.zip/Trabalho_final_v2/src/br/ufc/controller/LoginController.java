package br.ufc.controller;

import java.io.IOException;
import java.util.Random;

import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.*;
import br.ufc.model.*;

@Controller
@Transactional
public class LoginController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO userDAO;


	@RequestMapping("/loginForm")
	public String loginForm(){
		return "usuarios/login_form";
	}

	@RequestMapping("/login")
	public String login(Usuario u,HttpSession session){
		Usuario user = userDAO.recuperar(u.getLogin());
		u.setSenha(DigestUtils.md5Hex(u.getSenha()));
		if(user != null){
			if(user.getSenha().equals(u.getSenha())){
				session.setAttribute("usuario_logado", user);
				return "redirect:toHome";
			}
		}
		return "redirect:loginForm";
	}

	@RequestMapping("/logout")
	public String logout(HttpSession session){
		session.invalidate();
		return "redirect:loginForm";
	}
	
//	Recuperar a senha
	@RequestMapping("/recuperarSenhaForm")
	public String recuperarSenhaForm(){
		return "others/recuperar_senha_form"; 
	}
	
	@RequestMapping("/recuperarSenha")
	public String recuperarSenha(Usuario u) throws IOException, InterruptedException{
//		Encontro o usuario a partir do seu login
		Usuario novo = userDAO.recuperar(u.getLogin());
// Gero um numero aleatorio				
		Random gerador = new Random();		 
        int numero = gerador.nextInt();        
// Gero um hash md5 do numero aleatorio                 
        String s = DigestUtils.md5Hex(Integer.toString(numero));
// Seleciono os 10 primeiros caracteres        
        String novaSenha = s.substring(0, 10);
        
//        System.out.println(s.substring(0, 10));
// Chamo o script para o envio do email        
		Process r = Runtime.getRuntime().exec("python /tmp/myemail.py "		
		+novo.getEmail()+ " " + novaSenha);		
		r.waitFor();
// Aqui realizo o update da senha no usuario "novo".		
		novo.setSenha(DigestUtils.md5Hex(novaSenha));		
		userDAO.alterar(novo);
		return "redirect:loginForm";
	}
	
}




