package br.ufc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.ufc.dao.IFoto;
import br.ufc.model.Album;
import br.ufc.model.Comentario;
import br.ufc.model.Foto;
import br.ufc.model.Usuario;
import br.ufc.util.AulaFileUtil;

@Transactional
@Controller
public class FotoController {

	@Autowired
	@Qualifier(value="fotoDAOHibernate")
	private IFoto fotoDAO;


	@RequestMapping("/criarAlbumForm")
	public String criarAlbumForm(){		
		return "fotos/criar_album_form";
	}

	@Autowired
	private ServletContext context;

	@RequestMapping("/criarAlbum")
	public String criarAlbum(Album album, HttpSession session){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		album.setUsuario(u);
		fotoDAO.criarAlbum(album);
		return "redirect:toHome";
	}

	@RequestMapping("/listarAlbuns")
	public String listarAlbuns(Model model, HttpSession session){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");		
		List<Album> albuns = fotoDAO.listarAlbuns(u.getUsu_id());
		model.addAttribute("albuns",albuns);
		return "fotos/listarAlbuns";
	}

	//	Adicionar 'ListarAlbunsdeID', onde eu nao possa inserir mensagens

	@RequestMapping("/inserirFotoForm")
	public String inserirFotoForm(Long id, HttpSession session){
		Album album = fotoDAO.recuperarAlbum(id);
		session.setAttribute("obj", album);
		return "fotos/inserirFotoForm";
	}

	@RequestMapping("/inserirFoto")
	public String inserirFoto(Foto f,HttpSession session,@RequestParam(value="foto",
	required=false) MultipartFile image){		

		Album album = (Album) session.getAttribute("obj");
		Usuario u = (Usuario) session.getAttribute("usuario_logado");

		if ( image != null && !image.isEmpty() ){
			String path = context.getRealPath("/");
			path+="resources/album_images/"+f.getImagem()+".png";
			AulaFileUtil.saveFile(path, image);
		}		

		f.setAlbum(album);
		f.setUsuario(u);
		fotoDAO.inserirFoto(f);	

		return "redirect:listarAlbuns";
	}

	//	Listo as mensagens daquele album
	//	Para listar vou pegar todas as fotos do album
	@RequestMapping("/listarFotos")
	public String listarFotos(Model model, Long id){
//		Album a = fotoDAO.recuperarAlbum(id);
		List<Foto> fotos = fotoDAO.listarFotos(id);
		model.addAttribute("images",fotos);
		return "fotos/listarFotos";
	}

	@RequestMapping("/curtirFoto")
	public String curtir(Long id){
		Foto f  = fotoDAO.recuperarFoto(id);
		f.setCurtidas(f.getCurtidas()+1);
		fotoDAO.curtir(f);
		return "redirect:listarAlbuns";
	}

	// COMENTARIOS	
	@RequestMapping("/comentarFotoForm")
	public String comentarFotoForm(Long id, HttpSession session){
		Foto f = fotoDAO.recuperarFoto(id);		
		session.setAttribute("foto", f);
		return "fotos/comentarFotoForm";
	}

	@RequestMapping("/comentarFoto")
	public String comentarFoto(Comentario c, HttpSession session){
		Foto f = (Foto) session.getAttribute("foto");
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		c.setFoto(f);
		c.setUsu_id(u.getUsu_id());
		c.setLogin(u.getLogin());
		fotoDAO.comentarFoto(c);		
		return "redirect:listarAlbuns";
	}

	//	Listar Comentarios
	@RequestMapping("/listarComentarios")
	public String listarComentarios(Long id, Model model){
		List<Comentario> coms = fotoDAO.listarComentarios(id);
		model.addAttribute("comentarios",coms);
		return "fotos/listarComentarios";
	}
}
