package br.ufc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Categoria;
import br.ufc.model.Comunidade;
import br.ufc.model.Usuario;
import br.ufc.util.AulaFileUtil;

@Controller
@Transactional
public class ComunidadeController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;

	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;

	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;

	@Autowired
	private ServletContext context;

	@RequestMapping("/criarComunidadeForm")
	public String criarComunidadeForm(Model model){
		List<Categoria> cat = categoriaDAO.listarCategoria();
		model.addAttribute("categorias",cat);
		return "comunidades/criarComunidadeForm";
	}

	@RequestMapping("/criarComunidade")
	public String criarComunidade(Comunidade comunidade, 
			@RequestParam(value="image_cat",required=false) 
	MultipartFile image, HttpSession session){

		// Popular tabela USUARIO_COMUNIDADE
		List<Usuario> users = new ArrayList<Usuario>();
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		users.add(u);

		//			List<Comunidade> coms = new ArrayList<Comunidade>();
		//			coms.add(comunidade);

		if (image != null && ! image.isEmpty()){
			String path = context.getRealPath("/");
			path+="resources/images/"+comunidade.getNome()+"_com.png";
			AulaFileUtil.saveFile(path, image);
		}

		//Gambis is on!!
		Categoria cat = categoriaDAO.recuperar(comunidade.getAux());
		comunidade.setCategoria(cat);
		comunidade.setUsuarios(users);
		comunidadeDAO.criarComunidade(comunidade);
		return "redirect:listarComunidades";
	}

	//Listar Comunidades
	@RequestMapping("/listarComunidades")
	public String listarComunidades(Model model){		
		List<Comunidade> comunidades = comunidadeDAO.listarComunidades();
		model.addAttribute("comunidades", comunidades);	

		return "comunidades/listarComunidades";
	}

	@RequestMapping("/listarComunidadesDeId")
	public String listarComunidadesDeId(HttpSession session, Model model){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		List<Comunidade> c = comunidadeDAO.comunidadesDeId(u.getUsu_id());
		List<Comunidade> coms = new ArrayList<Comunidade>();

		for (Comunidade com: c){
			Long id = com.getCom_id();
			Comunidade nova = comunidadeDAO.recuperar(id);
			coms.add(nova);
		}

		model.addAttribute("comunidadesID",coms);

		return "comunidades/listarComunidadesDeId";
	}
	//	Realizar cadastro na comunidade
	@RequestMapping("/cadastroComunidade")
	public String cadastroComunidade(Long id,HttpSession session){
		Comunidade c = comunidadeDAO.recuperar(id);
		Usuario u = (Usuario) session.getAttribute("usuario_logado");						
		List<Usuario> users = new ArrayList<Usuario>();
		users.add(u);
		c.setUsuarios(users);
		comunidadeDAO.cadastroNaComunidade(c);		
		return "redirect:listarComunidades";
	}
}
