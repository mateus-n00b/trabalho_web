package br.ufc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.form.AmizadeCheckBoxForm;
import br.ufc.model.Amizade;
import br.ufc.model.Usuario;

@Controller
@Transactional
public class AmizadeController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;

	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;

	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;

	@Autowired
	private ServletContext context;

	//Inserir Amizades
	@RequestMapping("/inserirAmizadeForm")
	public String inserirAmizadeForm(HttpSession session, Model model){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");
		List<Usuario> broderagi = usuarioDAO.listar(); 
		broderagi.remove(u);

		AmizadeCheckBoxForm acf = new AmizadeCheckBoxForm();
		List<Amizade> minhasAmizades = this.amizadeDAO.listarAmizadesDeId(u.getUsu_id());		

		if (minhasAmizades != null && minhasAmizades.size() > 0){
			//Long[] vetorId = new Long[minhasAmizades.size()];
			//int i = 0;

			for(Amizade a: minhasAmizades){
				Long amigoId = a.getUsuarioAlvo().getUsu_id();
				Usuario amigoTemp = new Usuario();
				amigoTemp.setUsu_id(amigoId);
				broderagi.remove(amigoTemp);

				//vetorId[i] = amigoId;
				//i++;
			}
			//acf.setAmigos(vetorId);
		}

		model.addAttribute("amizades",acf);		
		model.addAttribute("usuario",u);
		model.addAttribute("amizade",broderagi);

		return "usuarios/inserir_amizade_form";
	}	

	// Criar broderagi
	@RequestMapping("/inserirAmizade")
	public String inserirAmizade(HttpSession session, AmizadeCheckBoxForm amizades){

		Usuario amigoFonte = (Usuario) session.getAttribute("usuario_logado");

		for (Long id : amizades.getAmigos()){
			Usuario amigoAlvo = usuarioDAO.recuperar(id);
			Amizade amizade = new Amizade();

			// Se sou amigo de X...
			amizade.setUsuarioFonte(amigoFonte);
			amizade.setUsuarioAlvo(amigoAlvo);						
			amizadeDAO.inserir(amizade);
			// Entao X e meu amigo			
			Amizade a = new Amizade();
			a.setUsuarioFonte(amigoAlvo);
			a.setUsuarioAlvo(amigoFonte);									
			amizadeDAO.inserir(a);
		}
		return "redirect:listarUsuarios";
	}

	// Listar Amigos
	@RequestMapping("/listarAmizade")
	public String listarAmizade(HttpSession session, Model model){
		Usuario u = (Usuario) session.getAttribute("usuario_logado");

		List<Amizade> amigos = this.amizadeDAO.listarAmizadesDeId(u.getUsu_id());
		// Array para armazenar todos os amigos do usuario atual
		List<Usuario> usuarios = new ArrayList<Usuario>(); 

		for(Amizade a: amigos){
			Long amigoId = a.getUsuarioAlvo().getUsu_id();			
			Usuario usuario = usuarioDAO.recuperar(amigoId);
			usuarios.add(usuario);			
		}

		model.addAttribute("amizades",usuarios);
		return "usuarios/listarAmizade";
	}

}
