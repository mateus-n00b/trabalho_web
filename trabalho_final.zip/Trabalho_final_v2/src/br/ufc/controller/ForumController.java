package br.ufc.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.ufc.dao.IAmizadeDAO;
import br.ufc.dao.ICategoria;
import br.ufc.dao.IComunidade;
import br.ufc.dao.IForum;
import br.ufc.dao.IMensagem;
import br.ufc.dao.IUsuarioDAO;
import br.ufc.model.Comunidade;
import br.ufc.model.Forum;

@Controller
@Transactional
public class ForumController {
	@Autowired
	@Qualifier(value="usuarioDAOHibernate")
	private IUsuarioDAO usuarioDAO;

	@Autowired
	@Qualifier(value="AmizadeDAOHib")
	private IAmizadeDAO amizadeDAO;

	@Autowired
	@Qualifier(value="comunidadeDAOHibernate")	
	private IComunidade comunidadeDAO;

	@Autowired
	@Qualifier(value="categoriaDAOHibernate")
	private ICategoria categoriaDAO;

	@Autowired
	@Qualifier(value="forumDAOHibernate")
	private IForum forumDAO;

	@Autowired
	@Qualifier(value="mensagemDAOHibernate")
	private IMensagem mensagemDAO;

	@Autowired
	private ServletContext context;

	// Criar Forum
	@RequestMapping("/criarForumForm")
	public String criarForumForm(Long id, HttpSession session ){			
		Comunidade c = comunidadeDAO.recuperar(id);
		session.setAttribute("com",c);
		return "foruns/criarForumForm"; 
	}

	@RequestMapping("/criarForum")
	public String criarForum(Forum forum, HttpSession session){
		Comunidade c = (Comunidade) session.getAttribute("com");		
		forum.setComunidade(c);
		comunidadeDAO.criarForum(forum);
		return "redirect:listarComunidades";
	}

	// Listar foruns	
	@RequestMapping("/listarForuns")
	public String listarForuns(Model model, Long id){
		List<Forum> foruns = comunidadeDAO.listarForuns(id);
		model.addAttribute("foruns",foruns);
		return "foruns/listarForuns";
	}
	
}
