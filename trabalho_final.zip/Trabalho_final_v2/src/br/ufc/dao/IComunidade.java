
package br.ufc.dao;

import java.util.List;

import br.ufc.model.Comunidade;
import br.ufc.model.Forum;

public interface IComunidade {
	public void criarForum(Forum forum);
	void criarComunidade(Comunidade comunidade);
	public List<Comunidade> listarComunidades();
	public Comunidade recuperar(Long id);
	public List<Forum> listarForuns(Long id);	
	public void cadastroNaComunidade(Comunidade c);	
	public List<Comunidade> comunidadesDeId(Long id);
}
