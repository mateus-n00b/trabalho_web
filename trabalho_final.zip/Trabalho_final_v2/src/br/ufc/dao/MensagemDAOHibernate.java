package br.ufc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import br.ufc.model.Mensagem;
@Repository
public class MensagemDAOHibernate implements IMensagem{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public Mensagem recuperar(Long id) {
		// TODO Auto-generated method stub
		return manager.find(Mensagem.class, id);
	}

	@Override
	public void curtir(Mensagem m) {
		// TODO Auto-generated method stub
		manager.merge(m);		
	}

}
