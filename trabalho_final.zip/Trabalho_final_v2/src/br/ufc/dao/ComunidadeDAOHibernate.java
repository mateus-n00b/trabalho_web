package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import br.ufc.model.Categoria;
import br.ufc.model.Comunidade;
import br.ufc.model.Forum;
import br.ufc.model.Orkut;
import br.ufc.model.Usuario;
@Repository
public class ComunidadeDAOHibernate implements IComunidade{
	@PersistenceContext
	private EntityManager manager; 
	
	@Override
	public void criarForum(Forum forum) {
		
		manager.persist(forum);
	}
	@Override
	public void criarComunidade(Comunidade comunidade){		
		Orkut o = manager.find(Orkut.class,1L);
		comunidade.setOrkut(o);
		manager.merge(comunidade);
	}	
	
	@Override
	public List<Comunidade> listarComunidades() {
		String hql = "select u from COMUNIDADE as u";
		return manager.createQuery(hql,Comunidade.class).getResultList();				 
	}
	
	@Override
	public List<Forum> listarForuns(Long id){
//		String hql = "select u from FORUM as u";
//		return manager.createQuery(hql,Forum.class).getResultList();

		String hql = "select a from FORUM as a where com_id = :var_id";
		Query query = manager.createQuery(hql);
		query.setParameter("var_id", id);
		
		return query.getResultList();
	}	
	
	@Override
	public Comunidade recuperar(Long id) {
		// TODO Auto-generated method stub
		return manager.find(Comunidade.class, id);
	}
	
	@Override
	public void cadastroNaComunidade(Comunidade c) {		
		manager.merge(c);
	}
}
