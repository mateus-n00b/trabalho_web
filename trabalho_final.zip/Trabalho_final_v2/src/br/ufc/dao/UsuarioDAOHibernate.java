package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import br.ufc.model.Orkut;
import br.ufc.model.Usuario;

@Repository
public class UsuarioDAOHibernate implements IUsuarioDAO{

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public void inserir(Usuario usuario) {
		Orkut o = manager.find(Orkut.class,1L);
		usuario.setOrkut(o);
		manager.persist(usuario);
	}
	
	@Override
	public void alterar(Usuario usuario) {
		// TODO Auto-generated method stub
		Orkut o = manager.find(Orkut.class,1L);
		usuario.setOrkut(o);
		manager.merge(usuario);
	}

	@Override
	public Usuario recuperar(Long id) {
		// TODO Auto-generated method stub
		return manager.find(Usuario.class, id);
	}

	@Override
	public Usuario recuperar(String login) {
		String hql = "select u from USUARIO as u where u.login=:var_login";		
		Query query = manager.createQuery(hql,Usuario.class);
		query.setParameter("var_login", login);
		List<Usuario> u = query.getResultList();
		if (u != null && !u.isEmpty()){
			return u.get(0);
		}
		return null;
	}

	@Override
	public List<Usuario> listar() {
		String hql = "select u from USUARIO as u";
		return manager.createQuery(hql,Usuario.class).getResultList();
				 
	}
	
	@Override
	public void apagar(Long id) {
		Usuario u = this.recuperar(id);
		manager.remove(u);
	}

}
