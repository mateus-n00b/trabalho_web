package br.ufc.dao;

import java.util.List;

import br.ufc.model.Album;
import br.ufc.model.Comentario;
import br.ufc.model.Foto;

public interface IFoto {
	public void criarAlbum(Album a);
	public List<Album> listarAlbuns(Long id);
	public void inserirFoto(Foto foto);
	public Album recuperarAlbum(Long id);
	public List<Foto> listarFotos(Long id);
	public void curtir(Foto f);
	public Foto recuperarFoto(Long id);
	public void comentarFoto(Comentario c);
	public List<Comentario> listarComentarios(Long id);	
}
