package br.ufc.dao;

import java.util.List;

import br.ufc.model.Categoria;
import br.ufc.model.Comunidade;

public interface ICategoria {
	public List<Categoria> listarCategoria();
	public void inserirCategoria();
	public Categoria recuperar(Long id);
}
