package br.ufc.dao;


import java.util.List;

import br.ufc.model.Comunidade;
import br.ufc.model.Usuario;

public interface IUsuarioDAO {
	public void inserir(Usuario u);
	public void alterar(Usuario u);
	public Usuario recuperar(Long id);
	public Usuario recuperar(String login);
	public List<Usuario> listar();
	public void apagar(Long id);
}
