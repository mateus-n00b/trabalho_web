package br.ufc.dao;

import br.ufc.model.Mensagem;

public interface IMensagem {
	public Mensagem recuperar(Long id);
	public void curtir(Mensagem m);
}
