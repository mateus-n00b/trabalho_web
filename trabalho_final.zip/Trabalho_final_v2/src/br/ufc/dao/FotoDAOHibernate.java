package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import br.ufc.model.Album;
import br.ufc.model.Comentario;
import br.ufc.model.Foto;
import br.ufc.model.Mensagem;
@Repository
public class FotoDAOHibernate implements IFoto {

	@PersistenceContext
	EntityManager manager;

	@Override
	public void criarAlbum(Album a) {
		manager.persist(a);		
	}

	@Override
	public List<Album> listarAlbuns(Long id) {
		String hql = "select a from ALBUM as a where usu_id = :var";
		Query query = manager.createQuery(hql);
		query.setParameter("var", id);
		return query.getResultList();		
	}
	
	@Override
	public Album recuperarAlbum(Long id){
		return manager.find(Album.class, id);
	}
	
	@Override
	public Foto recuperarFoto(Long id){
		return manager.find(Foto.class, id);
	}
	
	@Override
	public void inserirFoto(Foto foto) {
		manager.persist(foto);
	}

	@Override
	public List<Foto> listarFotos(Long id) {
		String hql = "select a from FOTO as a where al_id = :var";
		Query query = manager.createQuery(hql);
		query.setParameter("var", id);
		return query.getResultList();
	}
	
	@Override
	public void curtir(Foto f) {
		// TODO Auto-generated method stub
		manager.merge(f);		
	}
	
	@Override
	public void comentarFoto(Comentario c){
		manager.persist(c);
	}
	
	@Override
	public List<Comentario> listarComentarios(Long id){
		String hql = "select a from COMENTARIO as a where fot_id = :var";
		Query query = manager.createQuery(hql);
		query.setParameter("var", id);
		return query.getResultList();
	}
	
}
