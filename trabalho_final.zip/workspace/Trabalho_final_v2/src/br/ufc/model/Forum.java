package br.ufc.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name="FORUM")
public class Forum {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FOR_ID",nullable=false)
	private Long for_id;

	@Column(name="TITULO")
	private String titulo;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="COM_ID",referencedColumnName="COM_ID")	
	private Comunidade comunidade;
	// MANY-2-ONE

	// ONE-2-MANY
	@OneToMany(mappedBy="forum",targetEntity=Mensagem.class,fetch=FetchType.EAGER)
	private List<Mensagem> mensagens = new ArrayList<Mensagem>();
	// ONE-2-MANY

	public Long getFor_id() {
		return for_id;
	}

	public void setFor_id(Long for_id) {
		this.for_id = for_id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public Comunidade getComunidade() {
		return comunidade;
	}

	public void setComunidade(Comunidade comunidade) {
		this.comunidade = comunidade;
	}

	public List<Mensagem> getMensagens() {
		return mensagens;
	}

	public void setMensagens(List<Mensagem> mensagens) {
		this.mensagens = mensagens;
	}	

}
