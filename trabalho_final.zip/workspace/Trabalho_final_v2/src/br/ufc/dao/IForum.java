package br.ufc.dao;

import java.util.List;

import br.ufc.model.Forum;
import br.ufc.model.Mensagem;

public interface IForum {
	public Forum recuperar(Long id);
	public void inserirMensagem(Mensagem mensagem);
	public List<Mensagem> listarMensagens();
}
