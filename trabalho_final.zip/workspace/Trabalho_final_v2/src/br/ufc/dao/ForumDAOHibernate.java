package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import br.ufc.model.Forum;
import br.ufc.model.Mensagem;

@Repository
public class ForumDAOHibernate implements IForum{
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public Forum recuperar(Long id) {
		return manager.find(Forum.class, id);		
		
	}

		
	//Conserta depois trocar persist --> merge
	@Override
	public void inserirMensagem(Mensagem mensagem) {
		// TODO Auto-generated method stub
		manager.persist(mensagem);
	}


	@Override
	public List<Mensagem> listarMensagens() {
		// TODO Auto-generated method stub
		String hql = "select a from MENSAGEM as a";
		return manager.createQuery(hql,Mensagem.class).getResultList();
	}
	
}
