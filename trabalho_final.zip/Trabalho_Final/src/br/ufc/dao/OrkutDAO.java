package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import br.ufc.model.Orkut;
import br.ufc.model.Usuario;

public class OrkutDAO {
	public Orkut getId(){
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}

		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();
		Orkut o = manager.find(Orkut.class, 1L); 				
		manager.close();
		fab.close();
		return o;
	}
	public List<Usuario> listar(){
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}

		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();

		String hql = "select u from USUARIO as u";
		List<Usuario> users = 
				manager.createQuery(hql,Usuario.class).getResultList();

		manager.close();
		fab.close();

		return users;
	}
}
