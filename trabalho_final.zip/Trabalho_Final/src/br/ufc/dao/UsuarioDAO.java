package br.ufc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.taglibs.standard.lang.jstl.BooleanLiteral;

import br.ufc.model.Orkut;
import br.ufc.model.Usuario;

public class UsuarioDAO {

	public void inserir(Usuario u){
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}

		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();			

		manager.getTransaction().begin();
		manager.persist(u);
		manager.getTransaction().commit();

		manager.close();
		fab.close();
	}

	public boolean login(String login, String senha){
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}

		boolean var = false;

		OrkutDAO dao = new OrkutDAO();
		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();
		List<Usuario> users = dao.listar();

		for (Usuario u : users){
			if (senha.equals(u.getSenha())  &&
					login.equals(u.getLogin())){
				var = true;
			}else{
				var = false;
			}
		}		

		manager.close();
		fab.close();
		return var;
	}
}