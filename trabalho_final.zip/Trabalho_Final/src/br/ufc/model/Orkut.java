package br.ufc.model;

import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity(name="ORKUT")
public class Orkut {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ORK_ID")
	private Long ork_id;

	@Column(name="NOME")
	private String nome;

	@Column(name="DESCRICAO")
	private String descricao;


	// ONE-TO-MANY
	@OneToMany(mappedBy="orkut",targetEntity=Usuario.class,fetch=FetchType.EAGER)
	private Collection<Usuario> usuarios;
	// ONE-TO-MANY

	// ONE-TO-MANY
	@OneToMany(mappedBy="orkut",targetEntity=Comunidade.class,fetch=FetchType.EAGER)
	private Collection<Comunidade> comunidade;
	// ONE-TO-MANY

	public Long getOrk_id() {
		return ork_id;
	}

	public void setOrk_id(Long ork_id) {
		this.ork_id = ork_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Collection<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Collection<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public Collection<Comunidade> getComunidade() {
		return comunidade;
	}

	public void setComunidade(Collection<Comunidade> comunidade) {
		this.comunidade = comunidade;
	}

}
