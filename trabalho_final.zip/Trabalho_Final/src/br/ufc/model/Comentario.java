package br.ufc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="COMENTARIO")
public class Comentario {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="COM_ID")
	private Long com_id;

	@Column(name="TEXTO")
	private String texto;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="FOT_ID",
	referencedColumnName="FOT_ID")		
	private Foto foto;	
	// MANY-2-ONE

	public Long getCom_id() {
		return com_id;
	}

	public void setCom_id(Long com_id) {
		this.com_id = com_id;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Foto getFoto() {
		return foto;
	}

	public void setFoto(Foto foto) {
		this.foto = foto;
	}

}
