package br.ufc.model;

import java.util.Collection;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity(name="USUARIO")
public class Usuario {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USU_ID",nullable=false)
	private Long usu_id;

	@Column(name="NOME")
	private String nome;

	@Column(name="IDADE")
	private Long idade;

	@Column(name="EMAIL")
	private String email;

	@Column(name="LOGIN")
	private String login;

	@Column(name="SENHA")
	private String senha;

	@Column(name="AVATAR")
	private String avatar;
	
	// MANY-TO-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="ORK_ID",
	referencedColumnName="ORK_ID")	
	private Orkut orkut;
	//MANY-TO-ONE

		
	// ONE-TO-MANY
	@OneToMany(mappedBy="usuario",targetEntity=Foto.class,fetch=FetchType.EAGER)
	private Collection<Foto> fotos;
	// ONE-TO-MANY


	@ManyToMany
	@JoinTable(name="USUARIO_COMUNIDADE",
	joinColumns=@JoinColumn(name="USU_ID",referencedColumnName="USU_ID"),
	inverseJoinColumns=@JoinColumn(name="COM_ID", referencedColumnName="COM_ID"))

	private List<Comunidade> comunidades;

	public Long getUsu_id() {
		return usu_id;
	}

	public void setUsu_id(Long usu_id) {
		this.usu_id = usu_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Long getIdade() {
		return idade;
	}

	public void setIdade(Long idade) {
		this.idade = idade;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	

	public Collection<Foto> getFotos() {
		return fotos;
	}

	public void setFotos(Collection<Foto> fotos) {
		this.fotos = fotos;
	}

	public List<Comunidade> getComunidades() {
		return comunidades;
	}

	public void setComunidades(List<Comunidade> comunidades) {
		this.comunidades = comunidades;
	}

	public Orkut getOrkut() {
		return orkut;
	}

	public void setOrkut(Orkut orkut) {
		this.orkut = orkut;
	}

}
