package br.ufc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity(name="MENSAGEM")
public class Mensagem {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="MEN_ID",nullable=false)
	private Long men_id;

	@Column(name="TEXTO")
	private String texto;

	// MANY-2-ONE
	@ManyToOne(optional=false)
	@JoinColumn(name="FOR_ID",referencedColumnName="FOR_ID")	
	private Forum forum;
	// MANY-2-ONE

	public Long getMen_id() {
		return men_id;
	}

	public void setMen_id(Long men_id) {
		this.men_id = men_id;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Forum getForum() {
		return forum;
	}

	public void setForum(Forum forum) {
		this.forum = forum;
	}

}
