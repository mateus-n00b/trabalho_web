package br.ufc.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.http.HTTPException;

import br.ufc.dao.OrkutDAO;
import br.ufc.dao.UsuarioDAO;
import br.ufc.model.Orkut;
import br.ufc.model.Usuario;

@WebServlet("/cadastro")
public class CadastrarSevlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, 
			HttpServletResponse response) 
					throws ServletException, IOException {

		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String senha = request.getParameter("senha");
		Long idade = Long.parseLong(request.getParameter("idade"));
		String login = request.getParameter("login");
		String avatar = request.getParameter("avatar");		

		OrkutDAO o = new OrkutDAO();
		Usuario u = new Usuario();
		u.setAvatar(avatar);
		u.setEmail(email);
		u.setNome(nome);
		u.setLogin(login);
		u.setSenha(senha);
		u.setIdade(idade);	
		u.setOrkut(o.getId());
		PrintWriter out = response.getWriter();

		try{
			UsuarioDAO dao = new UsuarioDAO();
			dao.inserir(u);			
			out.write("<html>"
					+ "<body>"
					+ "Usuario cadastrado!"
					+ "</body>"
					+ "</html>");
			out.flush();
		}
		catch(HTTPException e){
			e.printStackTrace();
			out.write("<html>"
					+ "<body>"
					+ "Erro ao cadastrar usuario!"
					+ "</body>"
					+ "</html>");
			out.flush();

		}
	}
}
