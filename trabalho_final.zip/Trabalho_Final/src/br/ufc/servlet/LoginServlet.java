package br.ufc.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import javax.xml.ws.http.HTTPException;

import br.ufc.dao.UsuarioDAO;
import br.ufc.model.Usuario;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{
	boolean TOKEN = false;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");

		Usuario u = new Usuario();
		u.setLogin(login);
		u.setSenha(senha);
		UsuarioDAO dao = new UsuarioDAO();		
		PrintWriter out = response.getWriter();

		if (dao.login(login,senha)){ 
			out.write("<html>"
					+ "<body>"
					+ "Bem vindo!!!"
					+ "</body>"
					+ "</html>");
			out.flush();
			TOKEN = true;

		}else{	
			out.write("<html>"
					+ "<body>"
					+ "Login ou senha inválidos!"
					+ "</body>"
					+ "</html>");
			out.flush();
		}	
	}
}
