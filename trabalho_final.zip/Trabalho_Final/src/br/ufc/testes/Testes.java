package br.ufc.testes;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Testes {
	public static void main(String args[]){
		EntityManagerFactory fab = Persistence.createEntityManagerFactory("trabalho");
		//EntityManager manager = fab.createEntityManager();				
		
		//manager.close();
		fab.close();
	}
}
