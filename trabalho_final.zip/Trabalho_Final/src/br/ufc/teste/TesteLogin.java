package br.ufc.teste;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.ufc.dao.OrkutDAO;
import br.ufc.dao.UsuarioDAO;
import br.ufc.model.Usuario;

public class TesteLogin {
	public static void main(String []args){
		/*
		 List<Usuario> users = dao.listar();
		for (Usuario u : users){
				System.out.println("Senha1->"+u.getSenha());
				System.out.println("Login-> "+u.getLogin());
				if(u.getLogin() == "mateus-n00b" && u.getSenha() == "foobar@gmail.com"){
					System.out.println("OK");
				}
		}
		*/
		
		
		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();
		String hql = "select u from USUARIO as u ";
		List<Usuario> users = 
				manager.createQuery(hql,Usuario.class).getResultList();
		
		for(Usuario u:users){
			System.out.println("Login-> "+u.getLogin());
		}
		manager.close();
		fab.close();
	}
}
