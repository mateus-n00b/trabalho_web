package br.ufc.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.ufc.model.Orkut;

public class CriaORKUT {
	public static void main(String []args){
		
	Orkut o = new Orkut();
	o.setNome("Orkut");
	o.setDescricao("ORKUT BETA");	
	
	EntityManagerFactory fab = 
			Persistence.createEntityManagerFactory("trabalho_final");
	EntityManager manager = fab.createEntityManager();
	
	manager.getTransaction().begin();
	manager.persist(o);
	manager.getTransaction().commit();
	System.out.println("Done!");
	manager.close();
	fab.close();
	}
}

