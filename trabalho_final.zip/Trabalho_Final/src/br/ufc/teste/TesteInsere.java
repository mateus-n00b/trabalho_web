package br.ufc.teste;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.ufc.dao.OrkutDAO;
import br.ufc.model.Orkut;
import br.ufc.model.Usuario;

public class TesteInsere {
	public static void main(String []args){
		EntityManagerFactory fab = 
				Persistence.createEntityManagerFactory("trabalho_final");
		EntityManager manager = fab.createEntityManager();

		OrkutDAO dao = new OrkutDAO();
		Usuario u = new Usuario();
		/*List<Usuario> user = dao.listar();
		for(Usuario u : user){
			System.out.println("Login-> "+u.getLogin());
			System.out.println("Senha-> "+u.getSenha());
		}*/
		u.setAvatar("avatar");
		u.setEmail("foobar");
		u.setNome("mama");
		u.setLogin("lalal");
		u.setSenha("1234");
		u.setIdade(20L);
		u.setOrkut(dao.getId());			

		manager.persist(u);

		manager.close();
		fab.close();
	}
}
